def display_result (name, score, grade):
    if (grade == "f"):
        print(name + ", you failed.")
        print("Your grade: "+ grade)
    elif (grade== "a"):
        print("Congratulations," + name + ". You passed!" )
        print("Your grade: " + grade)
    else:
        print("Error.")