def get_student_data():
    name = input("Enter your name:")
    try:
    score = (input("Enter your Score (Integers only):"))
except ValueError:
raise TypeError ("Enter integer only!")
return name, score
