from input_module import get_student_data 
from output_module import display_result 
from logic_module import calculate_grade

def main():
    try:
        student_name, student_score = get_student_data()
        student_grade = calculate_grade (student_score)
        display_result(student_name, student_score, student_grade)

    except TypeError as e:
        print(f"\n[Error] {e}")
    except Exception as e:
        print(f"\n[System error]. Something went wrong:{e}")

        if __name __ == "__main__":
main()